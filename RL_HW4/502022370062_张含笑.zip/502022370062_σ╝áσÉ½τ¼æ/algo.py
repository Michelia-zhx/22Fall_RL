import numpy as np

from abc import abstractmethod
import torch
import torch.nn as nn

class QAgent:
    def __init__(self, envs, gamma=0.9, alpha=0.1):
        self.gamma = gamma
        self.alpha = alpha
        self.action_n = envs.action_shape
        self.grid_size = envs.image_size
        self.qtable = np.zeros((self.grid_size, self.grid_size, 2, self.action_n))

    @abstractmethod
    def select_action(self, ob):
        q_values = self.qtable[tuple(ob)]
        action = np.argmax(q_values)
        return action

    def update(self, ob, action, reward, next_ob, done):
        sa = tuple(np.append(ob, action))
        target = reward + (1 - done) * self.gamma * self.qtable[tuple(next_ob)].max()
        self.qtable[sa] += self.alpha * (target - self.qtable[sa])
        self.qtable[sa] = np.clip(self.qtable[sa], -100, 100)


class Model:
    def __init__(self):
        pass

    @abstractmethod
    def store_transition(self, s, a, r, s_):
        pass

    @abstractmethod
    def sample_state(self):
        pass

    @abstractmethod
    def sample_action(self, s):
        pass

    @abstractmethod
    def predict(self, s, a):
        pass


class DynaModel(Model):
    def __init__(self):
        Model.__init__(self)
        self.memory = {}

    def store_transition(self, s, a, r, s_):
        key = tuple(np.append(s, a))
        self.memory[key] = s_

    def sample_pair(self):
        choices = list(self.memory.keys())
        idx = np.random.choice(len(choices))
        sa = choices[idx]
        s = sa[:-1]
        a = sa[-1]
        return s, a

    def sample_state(self):
        pass

    def sample_action(self, s):
        pass

    def predict(self, s, a):
        search_key = tuple(np.append(s, a))
        return self.memory.get(search_key, None)

    def train_transition(self):
        pass


class NetworkModel(Model):
    def __init__(self, width, height, policy, args):
        Model.__init__(self)
        self.width = width
        self.height = height
        self.policy = policy
        self.network = FeedForwardModel()
        self.buffer = []
        self.criterion = nn.MSELoss()
        # self.optim = torch.optim.RMSprop(self.network.parameters(),lr=1e-5)
        self.optim = torch.optim.Adam(self.network.parameters(),lr=0.001)
        self.sensitive_index = []
        self.args = args

    def norm_s(self,s):
        return s

    def de_norm_s(self,s):
        s = np.clip(np.round(s), 0, self.width - 1).astype(np.int32)
        s[2] = np.clip(s[2], 0, 1).astype(np.int32)
        return s

    def store_transition(self, s, a, r, s_):
        s = self.norm_s(s)
        s_ = self.norm_s(s_)
        self.buffer.append([s, a, r, s_])
        if self.args.modify1:
            if s[-1] - s_[-1] != 0:
                self.sensitive_index.append(len(self.buffer) - 1)

    def train_transition(self, batch_size):
        s_list = []
        a_list = []
        r_list = []
        s_next_list = []
        for _ in range(batch_size):
            idx = np.random.randint(0, len(self.buffer))
            s, a, r, s_ = self.buffer[idx]
            s_list.append(s)
            a_list.append([a])
            r_list.append(r)
            s_next_list.append(s_)

        if self.args.modify1:
            if len(self.sensitive_index) > 0:
                for _ in range(batch_size):
                    idx = np.random.randint(0, len(self.sensitive_index))
                    idx = self.sensitive_index[idx]
                    s, a, r, s_ = self.buffer[idx]
                    s_list.append(s)
                    a_list.append([a])
                    r_list.append(r)
                    s_next_list.append(s_)

        s_tensor = torch.tensor(s_list).float()
        a_tensor = torch.tensor(a_list).float()
        s_next_tensor = torch.tensor(s_next_list).float()
        predict = self.network(s_tensor, a_tensor)
        loss = self.criterion(predict, s_next_tensor)
        self.optim.zero_grad()
        loss.backward()
        self.optim.step()
        return loss.item()

    def sample_state(self):
        idx = np.random.randint(0, len(self.buffer))
        s, a, r, s_ = self.buffer[idx]
        return self.de_norm_s(s)

    def sample_action(self, s):
        return self.policy.select_action(s)

    def predict(self, s, a):
        s_tensor = torch.tensor(s).float()
        a_tensor = torch.tensor(a).float().reshape([1])
        with torch.no_grad():
            s_ = self.network(s_tensor,a_tensor)
        s_ = s_.numpy()
        return self.de_norm_s(s_)


class FeedForwardModel(nn.Module):
    def __init__(self):
        super(FeedForwardModel, self).__init__()
        self.network = nn.Sequential(
            nn.Linear(4,256),
            nn.ReLU(),
            nn.Linear(256,256),
            nn.ReLU(),
            nn.Linear(256,3),
            nn.Tanh()
        )

    def forward(self, s, a):
        x = torch.cat((s, a),dim = -1)
        pred = self.network(x) * 1.3
        pred = pred + s
        return pred


# class NetworkModel(Model):
#     def __init__(self, width, height, policy):
#         Model.__init__(self, width, height, policy)
#         self.x_ph = tf.placeholder(dtype=tf.float32, shape=[None, 3], name='x')
#         self.x_next_ph = tf.placeholder(dtype=tf.float32, shape=[None, 3], name='x_next')
#         self.a_ph = tf.placeholder(dtype=tf.float32, shape=[None, 1], name='a')
#         self.r_ph = tf.placeholder(dtype=tf.float32, shape=[None], name='r')
#         h1 = tf.layers.dense(tf.concat([self.x_ph, self.a_ph], axis=-1), units=256, activation=tf.nn.relu)
#         h2 = tf.layers.dense(h1, units=256, activation=tf.nn.relu)
#         self.next_x = tf.layers.dense(h2, units=3, activation=tf.nn.tanh) * 1.3 + self.x_ph
#         self.x_mse = tf.reduce_mean(tf.square(self.next_x - self.x_next_ph))
#         self.opt_x = tf.train.RMSPropOptimizer(learning_rate=1e-5).minimize(self.x_mse)
#         gpu_options = tf.GPUOptions(allow_growth=True)
#         tf_config = tf.ConfigProto(gpu_options=gpu_options)
#         self.sess = tf.Session(config=tf_config)
#         self.sess.run(tf.variables_initializer(tf.global_variables()))
#         self.buffer = []
#         self.sensitive_index = []

#     def norm_s(self, s):
#         return s

#     def de_norm_s(self, s):
#         s = np.clip(np.round(s), 0, self.width - 1).astype(np.int32)
#         s[2] = np.clip(s[2], 0, 1).astype(np.int32)
#         return s

#     def store_transition(self, s, a, r, s_):
#         s = self.norm_s(s)
#         s_ = self.norm_s(s_)
#         self.buffer.append([s, a, r, s_])
#         if s[-1] - s_[-1] != 0:
#             self.sensitive_index.append(len(self.buffer) - 1)

#     def train_transition(self, batch_size):
#         s_list = []
#         a_list = []
#         r_list = []
#         s_next_list = []
#         for _ in range(batch_size):
#             idx = np.random.randint(0, len(self.buffer))
#             s, a, r, s_ = self.buffer[idx]
#             s_list.append(s)
#             a_list.append([a])
#             r_list.append(r)
#             s_next_list.append(s_)

#         x_mse = self.sess.run([self.x_mse,  self.opt_x], feed_dict={
#             self.x_ph: s_list, self.a_ph: a_list, self.x_next_ph: s_next_list
#         })[:1]
#         return x_mse

#     def sample_state(self):
#         idx = np.random.randint(0, len(self.buffer))
#         s, a, r, s_ = self.buffer[idx]
#         return self.de_norm_s(s), idx

#     def sample_action(self, s):
#         return self.policy.select_action(s)

#     def predict(self, s, a):
#         s_ = self.sess.run(self.next_x, feed_dict={self.x_ph: [s], self.a_ph: [[a]]})
#         return self.de_norm_s(s_[0])
